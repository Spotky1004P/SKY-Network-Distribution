//include <scripts/pck_importPackage.js>

function onUpdate(su){
	//include <scripts/pck_basicFunction.js>

	//include <scripts/pck_main/toshiba_IGBT.js>

	deadsection(entity, dataMap, 0);
	doorBeep(entity, dataMap, 0, 2000);
	
}
//include <scripts/pck_plugin/deadsection.js>
//include <scripts/pck_plugin/doorBeep.js>
