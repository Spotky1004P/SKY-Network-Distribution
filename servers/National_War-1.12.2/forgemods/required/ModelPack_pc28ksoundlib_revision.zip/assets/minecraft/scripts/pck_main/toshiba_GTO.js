function allmute(){
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor0');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor1');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor2');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor3');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor4');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor5');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor6');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor7');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor8');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor9');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor10');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor11');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor12');
}

su.playSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_loop', 1.0, 1.0);

if(notch > 0){
	//역행
	if(speed > 0 && speed <= 5){
		if(speed <= 4){
			mvol = linener(speed, 0, 0.32, 4, 0.35);
		}else{
			mvol = linener(speed, 4, 0.35, 5, 0);
		}
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor0', (mvol*1.8), 1);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor0');	}
	
	if(speed > 4.2 && speed <= 10){
		if(speed <= 8.6){
			mvol = linener(speed, 4.2, 0.3, 8.6, 0.45);
		}else{
			mvol = linener(speed, 8.6, 0.5, 9.6, 0);
		}
		mpit = linener(speed, 4.2, 0.75, 10, 1.5);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor1', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor1');	}
	
	if(speed > 8.6 && speed <= 18){
		if(speed <= 15){
			mvol = linener(speed, 8.6, 0.38, 16, 0.44);
		}else{
			mvol = linener(speed, 15, 0.44, 18, 0);
		}
		mpit = linener(speed, 8.2, 1, 18, 1.31);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor2', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor2');	}
	
	if(speed > 16 && speed <= 30){
		if(speed <= 28.2){
			mvol = linener(speed, 16, 0.39, 28.2, 0.48);
		}else{
			mvol = linener(speed, 28.2, 0.48, 30, 0);
		}
		mpit = linener(speed, 16, 1, 30, 1.23);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor3', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor3');	}
	
	if(speed > 25 && speed <= 38){
		if(speed <= 36.4){
			mvol = linener(speed, 25, 0.2, 36.4, 0.56);
		}else{
			mvol = linener(speed, 36.4, 0.56, 38, 0);
		}
		mpit = linener(speed, 27.8, 1, 38, 1.29);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor4', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor4');	}
	
	if(speed > 36.6 && speed <= 55){
		if(speed <= 49.8){
			mvol = linener(speed, 36.6, 0.37, 49.8, 0.58);
		}else{
			mvol = linener(speed, 49.8, 0.58, 55, 0);
		}
		mpit = linener(speed, 36.6, 1, 51, 1.24);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor5', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor5');	}
	
	if(speed > 40.0){
		if(speed <= 51){
			mvol = linener(speed, 40, 0.01, 51, 0.2);
		}else{
			mvol = linener(speed, 51, 0.2, 120, 0.8);
		}
		mpit = linener(speed, 47.4, 0.89, 120, 1.56);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor7', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor7');	}
	

}else if(notch < 0){
	//제동
	if(speed >= 1 && speed <= 10){
		if(speed <= 11){
			mvol = linener(speed, 0, 0.24, 11, 0.35);
		}else{
			mvol = linener(speed, 11, 0.35, 15, 0);
		}
		mpit = linener(speed, 0, 0.83, 15, 1);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor0', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor0');	}
	
	if(speed > 9 && speed <= 19){
		if(speed <= 11.2){
			mvol = linener(speed, 9, 0.01, 11.2, 0.48);
		}else{
			mvol = linener(speed, 11.2, 0.48, 8.4, 0.5);
		}
		mpit = linener(speed, 9.8, 0.87, 18.4, 1);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor9', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor9');	};
	
	if(speed > 18 && speed <= 31){
		if(speed <= 19.2){
			mvol = linener(speed, 18, 0.01, 19.2, 0.53);
		}else{
			mvol = linener(speed, 19.2, 0.53, 29.6, 0.6);
		}
		mpit = linener(speed, 18, 0.8, 29.6, 1);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor10', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor10');	};
	
	if(speed > 29 && speed <= 38){
		if(speed <= 30.4){
			mvol = linener(speed, 29, 0.13, 30.4, 0.56);
		}else{
			mvol = linener(speed, 30.4, 0.56, 38, 0.52);
		}
		mpit = linener(speed, 29, 0.86, 38, 1);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor11', (mvol*1.5), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor11');	};
	
	if(speed > 36.6 && speed <= 51.4){
		if(speed <= 38.4){
			mvol = linener(speed, 36.6, 0.01, 38.4, 0.57);
		}else{
			mvol = linener(speed, 38.4, 0.57, 38, 0.43);
		}
		mpit = linener(speed, 36.6, 0.81, 51.4, 1);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor12', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor12');	};
	
	if(speed > 36.6 && speed <= 51.4){
		if(speed <= 38.4){
			mvol = linener(speed, 36.6, 0.01, 38.4, 0.57);
		}else{
			mvol = linener(speed, 38.4, 0.57, 51.4, 0.43);
		}
		mpit = linener(speed, 36.6, 0.81, 51.4, 1);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor12', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor12');	};
	
	if(speed > 40.0){
		if(speed <= 51){
			mvol = linener(speed, 40, 0.01, 51, 0.2);
		}else{
			mvol = linener(speed, 51, 0.2, 120, 0.8);
		}
		mpit = linener(speed, 47.4, 0.89, 120, 1.56);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor7', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_motor7');	}
	}else{
	//타행
	allmute();
	
}

if(speed == 0){
	allmute();
}

if(speed < 50){
	mvolr = linener(speed, 5, 0.01, 50, 1);
}else{
	mvolr = linener(speed, 50, 1, 100, 2);
}
mpitr = linener(speed, 0, 0, 100, 1.2);
if(mvol < 0){
	mvol = 0;
}
if(su.inTunnel()){
	su.playSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_run2', (mvolr*1.5), mpitr);
}else{
	su.playSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_run2', 0, 1);
}
su.playSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_run0', (mvolr*1.5), mpitr);