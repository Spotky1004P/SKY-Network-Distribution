function signalChange(entity, dataMap, soundType){
    if(entity.getTrainStateData(10) != 1){
        var TCC = TrainControllerClientManager.getTCC(entity);
        //Type별 이름 설정
		var typeNameList = ["train.rtm_pck_signalChange_type1", "train.rtm_pck_signalChange_type2"];

        if(dataMap.getInt('pcksl_prevSignal') != entity.getSignal()){
            soundPlay();
        }

        if(TCC != null){
            if(dataMap.getInt('pcksl_prevATC') != TCC.getATCSpeed()){
                soundPlay();
            }
        }

        dataMap.setInt('pcksl_prevSignal', entity.getSignal(), 0);
        if(TCC != null){
            dataMap.setInt('pcksl_prevATC', TCC.getATCSpeed(), 0);
        }

        function soundPlay(){
            var now = Date.now();
            if(pck_signalChange_starttime+500 < now){
                pck_signalChange_starttime = Date.now();
                var path = new ResourceLocation("sound_pck2", typeNameList[soundType]);
			    RTMCore.proxy.playSound(entity, path, 1, 1);
            }
		}
    }
}
var pck_signalChange_starttime = 0;