function deadsection(entity, dataMap, soundType){
	if(entity.getTrainStateData(10) != 1){
		//Type별 이름, 길이 설정
		var typeNameList = ["train.rtm_pck_deadsection_type1"];
		var typeTermList = [5500];

		//섹션 진입
		if(dataMap.getInt("pck_deadsection") == 1){
			dataMap.setInt("pck_deadsection", 2, 0);//←통과중으로 변경
			//↓최초1회 실행
			if(pck_deadsection_first != 1){
				soundPlay()
				//dataMap.setDouble("pck_deadsection_starttime", Date.now(), 0);
				pck_deadsection_starttime = Date.now(); //↑datamap제외갱신
				pck_deadsection_first = 1;
			}
		}
		
		//섹션 통과중
		if(dataMap.getInt("pck_deadsection") == 2){
			var now = Date.now();
			//var starttime = dataMap.getDouble("pck_deadsection_starttime");
			var starttime = pck_deadsection_starttime; //↑datamap제외갱신
			//↓간격두고 반복 실행
			if(now > typeTermList[soundType] + starttime){
				pck_deadsection_first = 0;
				//dataMap.setDouble("pck_deadsection_starttime", now, 0);//타이머 초기화
				pck_deadsection_starttime = now; //↑datamap제외갱신
				soundPlay()
			}
		}

		function soundPlay(){
			var path = new ResourceLocation("sound_pck2", typeNameList[soundType]);
			RTMCore.proxy.playSound(entity, path, 1, 1);
		}
	}
}
//pck_deadsection 0: 종료/섹션아님  1: 시작  2: 통과중

var pck_deadsection_first;
var pck_deadsection_starttime;