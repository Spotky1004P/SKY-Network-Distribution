function allmute(){
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor0');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor1');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor2');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor3');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor4');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor5');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor6');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor7');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor8');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor9');
}

//플래그변수초기화
if(!!!pck_flag[0])	pck_flag[0] = 0;

if(notch > 0){
	//역행
	if(speed > 0 && speed <= 9){
		if(speed <= 1){
			mvol = linener(speed, 0, 0.01, 1, 0.4);
		}else{
			mvol = linener(speed, 1, 0.4, 9, 0.6);
		}
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor0', (mvol*1.8), 1);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor0');	}
	
	if(speed > 0 && speed <= 25){
		if(speed <= 10){
			mvol = linener(speed, 0, 0.01, 10, 0.27);
		}else{
			mvol = linener(speed, 10, 0.27, 25, 0.42);
		}
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor8', (mvol*1.8), 1);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor8');	}
	
	if(speed > 2.4 && speed <= 20){
		if(speed <= 7.8){
			mvol = linener(speed, 2.4, 0.01, 7.8, 0.18);
		}else if(speed <= 10.6){
			mvol = linener(speed, 7.8, 0.22, 10.6, 0.53);
		}else if(speed <= 13.6){
			mvol = 0.53;
		}else if(speed <= 17){
			mvol = linener(speed, 13.6, 0.53, 17, 0.45);
		}else{
			mvol = linener(speed, 17, 0.45, 20, 0);
		}
		mpit = linener(speed, 2.4, 0.2, 20, 1.37);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor1', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor1');	}
	
	if(speed > 11 && speed <= 26){
		if(speed <= 17){
			mvol = linener(speed, 11, 0.01, 17, 0.5);
		}else if(speed <= 21){
			mvol = linener(speed, 17, 0.5, 21, 0.56);
		}else{
			mvol = linener(speed, 21, 0.56, 26, 0.5);
		}
		mpit = linener(speed, 11, 0.65, 25, 1.3);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor2', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor2');	}

	if(speed > 24 && speed <= 25){
		//pck_flag[0]	0: 대기, 1: 재생함
		if(pck_flag[0] == 0){
			var path = new ResourceLocation("sound_pck2", "train.rtm_pck_toshiba_PMSM_motor3");
			RTMCore.proxy.playSound(entity, path, 0.7, 1);
			pck_flag[0] = 1;
		}
	}
	else pck_flag[0] = 0;
	
	if(speed > 24 && speed <= 50){
		if(speed <= 25.5){
			mvol = linener(speed, 24, 0.01, 25.5, 0.5);
		}else if(speed <= 35){
			mvol = linener(speed, 26.5, 0.5, 35, 0.47);
		}else if(speed <= 45){
			mvol = linener(speed, 35, 0.47, 45, 0.07);
		}else{
			mvol = linener(speed, 45, 0.07, 50, 0.02);
		}
		mpit = linener(speed, 25, 0.94, 50, 1.67);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor4', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor4');	}
	
	if(speed > 30 && speed <= 70){
		if(speed <= 45){
			mvol = linener(speed, 30, 0.03, 45, 0.43);
		}else if(speed <= 50){
			mvol = linener(speed, 45, 0.43, 50, 0.47);
		}else if(speed <= 55){
			mvol = linener(speed, 50, 0.47, 55, 0.43);
		}else{
			mvol = linener(speed, 55, 0.43, 70, 0.02);
		}
		mpit = linener(speed, 30, 0.8, 50, 1.19);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor5', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor5');	}
	
	if(speed > 50){
		if(speed <= 59){
			mvol = linener(speed, 50, 0.02, 59, 0.2);
		}else if(speed <= 65){
			mvol = linener(speed, 59, 0.2, 65, 0.4);
		}else if(speed <= 75){
			mvol = linener(speed, 65, 0.4, 75, 0.5);
		}else{
			mvol = linener(speed, 75, 0.5, 85, 0.47);
		}
		mpit = linener(speed, 50, 0.89, 100, 1.56);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor6', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor6');	}
	
	if(speed > 65){
		mvol = linener(speed, 65, 0.01, 100, 0.11);
		mpit = linener(speed, 65, 0.91, 100, 1);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor7', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor7');	}
	
}else if(notch < 0){
	//제동
	/*
	if(speed > 0 && speed < 10){
		if(speed <= 4.5){
			mvol = linener(speed, 0, 0.21, 4.5, 0.29);
		}else if(speed <= 7){
			mvol = linener(speed, 4.5, 0.29, 7, 0.38);
		}else if(speed <= 7.6){
			mvol = linener(speed, 7, 0.38, 7.6, 0.04);
		}else{
			mvol = linener(speed, 7.6, 0.04, 10, 0.01);
		}
		if(speed <= 6.7){
			mpit = linener(speed, 6.7, 1, 10, 1.82);
		}else{
			mpit = 1;
		}
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor9', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor9');	}
	*/
	if(speed > 0 && speed < 8.3){
		if(speed <= 0.8){
			mvol = linener(speed, 0, 0, 0.8, 0.29);
		}else if(speed <= 3.2){
			mvol = linener(speed, 0.8, 0.29, 3.2, 0.37);
		}else if(speed <= 7){
			mvol = linener(speed, 3.2, 0.37, 7, 0.43);
		}else if(speed <= 7.3){
			mvol = linener(speed, 7, 0.43, 7.3, 0.03);
		}else{
			mvol = linener(speed, 7.3, 0.03, 8.3, 0);
		}
		mpit = 1;
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor0', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor0');	}
	
	if(speed > 0 && speed <= 25){
		if(speed <= 10){
			mvol = linener(speed, 0, 0.01, 10, 0.27);
		}else{
			mvol = linener(speed, 10, 0.27, 25, 0.42);
		}
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor8', (mvol*1.8), 1);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor8');	}
	
	if(speed > 2.4 && speed <= 20){
		if(speed <= 7.8){
			mvol = linener(speed, 2.4, 0.01, 7.8, 0.18);
		}else if(speed <= 10.6){
			mvol = linener(speed, 7.8, 0.22, 10.6, 0.53);
		}else if(speed <= 13.6){
			mvol = 0.53;
		}else if(speed <= 17){
			mvol = linener(speed, 13.6, 0.53, 17, 0.45);
		}else{
			mvol = linener(speed, 17, 0.45, 20, 0);
		}
		mpit = linener(speed, 2.4, 0.2, 20, 1.37);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor1', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor1');	}
	
	if(speed > 11 && speed <= 26){
		if(speed <= 17){
			mvol = linener(speed, 11, 0.01, 17, 0.5);
		}else if(speed <= 21){
			mvol = linener(speed, 17, 0.5, 21, 0.56);
		}else{
			mvol = linener(speed, 21, 0.56, 26, 0.5);
		}
		mpit = linener(speed, 11, 0.65, 25, 1.3);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor2', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor2');	}
	
	if(speed > 24 && speed <= 50){
		if(speed <= 25.5){
			mvol = linener(speed, 24, 0.01, 25.5, 0.5);
		}else if(speed <= 35){
			mvol = linener(speed, 26.5, 0.5, 35, 0.47);
		}else if(speed <= 45){
			mvol = linener(speed, 35, 0.47, 45, 0.07);
		}else{
			mvol = linener(speed, 45, 0.07, 50, 0.02);
		}
		mpit = linener(speed, 25, 0.94, 50, 1.67);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor4', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor4');	}
	
	if(speed > 30 && speed <= 70){
		if(speed <= 45){
			mvol = linener(speed, 30, 0.03, 45, 0.43);
		}else if(speed <= 50){
			mvol = linener(speed, 45, 0.43, 50, 0.47);
		}else if(speed <= 55){
			mvol = linener(speed, 50, 0.47, 55, 0.43);
		}else{
			mvol = linener(speed, 55, 0.43, 70, 0.02);
		}
		mpit = linener(speed, 30, 0.8, 50, 1.19);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor5', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor5');	}
	
	if(speed > 50){
		if(speed <= 59){
			mvol = linener(speed, 50, 0.02, 59, 0.2);
		}else if(speed <= 65){
			mvol = linener(speed, 59, 0.2, 65, 0.4);
		}else if(speed <= 75){
			mvol = linener(speed, 65, 0.4, 75, 0.5);
		}else{
			mvol = linener(speed, 75, 0.5, 85, 0.47);
		}
		mpit = linener(speed, 50, 0.89, 100, 1.56);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor6', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor6');	}
	
	if(speed > 65){
		mvol = linener(speed, 65, 0.01, 100, 0.11);
		mpit = linener(speed, 65, 0.91, 100, 1);
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor7', (mvol*1.8), mpit);
	}else{	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_PMSM_motor7');	}
}else{
	//타행
	allmute();
}

if(speed == 0){
	allmute();
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_run0');
	su.stopSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_run2');
}
else{
	if(speed < 50){
		mvolr = linener(speed, 5, 0.01, 50, 1);
	}else{
		mvolr = linener(speed, 50, 1, 100, 2);
	}
	mpitr = linener(speed, 0, 0, 100, 1.2);
	if(mvol < 0){
		mvol = 0;
	}
	if(su.inTunnel()){
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_run2', (mvolr*1.2), mpitr);
	}else{
		su.playSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_run2', 0, 1);
	}
	su.playSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_run0', (mvolr*1.5), mpitr);
}