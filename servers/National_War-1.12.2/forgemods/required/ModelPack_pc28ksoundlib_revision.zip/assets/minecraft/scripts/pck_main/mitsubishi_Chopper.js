function allmute(){
	su.stopSound('sound_pck2', 'train.rtm_pck_mitsubishi_Chopper_0');
	su.stopSound('sound_pck2', 'train.rtm_pck_mitsubishi_Chopper_1');
	su.stopSound('sound_pck2', 'train.rtm_pck_mitsubishi_Chopper_2');
	su.stopSound('sound_pck2', 'train.rtm_pck_mitsubishi_Chopper_3');
	su.stopSound('sound_pck2', 'train.rtm_pck_mitsubishi_Chopper_5');
}

su.playSound('sound_pck2', 'train.rtm_pck_mitsubishi_Chopper_loop', 0.7, 1);

if(notch > 0){
	//역행
	if(0 < speed && speed < 1){
		if(dataMap.getInt('pcksl_flag0') == 0){
			var path = new ResourceLocation("sound_pck2", "train.rtm_pck_mitsubishi_Chopper_click");
			RTMCore.proxy.playSound(entity, path, 1, 1);
			dataMap.setInt('pcksl_flag0', 1, 0);
		}
	}
	else dataMap.setInt('pcksl_flag0', 0, 0);

	if(speed > 0){
		if(speed > 0 && speed <= 6)
			mvol = linener(speed, 0, 0.01, 6, 1);
		else
			mvol = 1;

		su.playSound('sound_pck2', 'train.rtm_pck_mitsubishi_Chopper_0', (mvol*1.8), 1);
	}
	else	su.stopSound('sound_pck2', 'train.rtm_pck_mitsubishi_Chopper_0');

	if(3 < speed && speed <= 13){
		if(speed <= 6)
			mvol = linener(speed, 3, 0.01, 6, 0.5);
		else if(speed <= 10)
			mvol = 0.5;
		else
			mvol = linener(speed, 10, 0.5, 13, 0.0);
		mpit = linener(speed, 3, 0.5, 12, 1.5);
		su.playSound('sound_pck2', 'train.rtm_pck_mitsubishi_Chopper_5', (mvol*1.8), mpit);
	}
	else	su.stopSound('sound_pck2', 'train.rtm_pck_mitsubishi_Chopper_5');
	
	if(6 < speed && speed <= 20){
		if(speed <= 7)
			mvol = linener(speed, 6, 0.01, 8, 0.8);
		else
			mvol = 0.8;
		mpit = linener(speed, 4, 0.5, 20, 1.5);
		su.playSound('sound_pck2', 'train.rtm_pck_mitsubishi_Chopper_1', (mvol*1.8), mpit);
	}
	else	su.stopSound('sound_pck2', 'train.rtm_pck_mitsubishi_Chopper_1');

	if(20 < speed && speed <= 48){
		mvol = 0.8;
		mpit = linener(speed, 20, 0.75, 48, 2);
		su.playSound('sound_pck2', 'train.rtm_pck_mitsubishi_Chopper_2', (mvol*1.8), mpit);
	}
	else	su.stopSound('sound_pck2', 'train.rtm_pck_mitsubishi_Chopper_2');

	if(48 < speed){
		mvol = 0.8;
		mpit = linener(speed, 48, 1, 94, 2);
		su.playSound('sound_pck2', 'train.rtm_pck_mitsubishi_Chopper_3', (mvol*1.8), mpit);
	}
	else	su.stopSound('sound_pck2', 'train.rtm_pck_mitsubishi_Chopper_3');
	
}else if(notch < 0){
	//제동
	if(18 < speed && speed < 21){
		if(dataMap.getInt('pcksl_flag0') == 0){
			var path = new ResourceLocation("sound_pck2", "train.rtm_pck_mitsubishi_Chopper_click");
			RTMCore.proxy.playSound(entity, path, 1, 1);
			dataMap.setInt('pcksl_flag0', 1, 0);
		}
	}
	else dataMap.setInt('pcksl_flag0', 0, 0);

	if(4 < speed && speed <= 20){
		if(speed <= 7)
			mvol = linener(speed, 4, 0.01, 7, 0.4);
		else if(speed <= 15)
			mvol = 0.4;
		else
			mvol = linener(speed, 15, 0.4, 20, 0.1);
		mpit = linener(speed, 4, 0.5, 20, 1.5);
		su.playSound('sound_pck2', 'train.rtm_pck_mitsubishi_Chopper_1', (mvol*1.8), mpit);
	}
	else	su.stopSound('sound_pck2', 'train.rtm_pck_mitsubishi_Chopper_1');

	if(speed > 19){
		if(19 < speed  && speed <= 21)
			mvol = linener(speed, 19, 0.01, 21, 1);
		else
			mvol = 1;
		su.playSound('sound_pck2', 'train.rtm_pck_mitsubishi_Chopper_0', (mvol*1.8), 1);
	}
	else	su.stopSound('sound_pck2', 'train.rtm_pck_mitsubishi_Chopper_0');

	if(20 < speed && speed <= 48){
		if(speed <= 25)
			mvol = linener(speed, 20, 0.01, 25, 0.6);
		else if(speed <= 30)
			mvol = linener(speed, 25, 0.6, 30, 0.8);
		else
			mvol = 0.8;
		mpit = linener(speed, 25, 1, 48, 2);
		su.playSound('sound_pck2', 'train.rtm_pck_mitsubishi_Chopper_2', (mvol*1.8), mpit);
	}
	else	su.stopSound('sound_pck2', 'train.rtm_pck_mitsubishi_Chopper_2');

	if(48 < speed){
		mvol = 0.8;
		mpit = linener(speed, 48, 1, 94, 2);
		su.playSound('sound_pck2', 'train.rtm_pck_mitsubishi_Chopper_3', (mvol*1.8), mpit);
	}
	else	su.stopSound('sound_pck2', 'train.rtm_pck_mitsubishi_Chopper_3');
	
}else{
	//타행
	allmute();
}

if(50 < speed){
	if(speed <= 62)
		mvol = linener(speed, 50, 0.01, 62, 1);
	else
		mvol = linener(speed, 62, 1, 100, 1.5);
	mpit = linener(speed, 50, 0.5, 90, 1);
	if(notch == 0)	mvol = mvol * 0.7;
	su.playSound('sound_pck2', 'train.rtm_pck_mitsubishi_Chopper_4', (mvol*1.6), mpit);
}
else	su.stopSound('sound_pck2', 'train.rtm_pck_mitsubishi_Chopper_4');

if(speed == 0){
	allmute();
}

if(speed < 50){
	mvolr = linener(speed, 5, 0.01, 50, 1);
}else{
	mvolr = linener(speed, 50, 1, 100, 2);
}
mpitr = linener(speed, 0, 0.0, 100, 1.2);
if(su.inTunnel()){
	su.playSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_run2', (mvolr*1.2), mpitr);
}else{
	su.playSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_run2', 0, 1);
}
su.playSound('sound_pck2', 'train.rtm_pck_toshiba_GTO_run0', (mvolr*1.5), mpitr);