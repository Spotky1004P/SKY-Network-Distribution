function flangeNoise(entity, soundType){
	var angleF = entity.getBogie(0).field_70177_z;
	var angleB = entity.getBogie(1).field_70177_z -180;
	NGTLog.debug(angleF-angleB);
}