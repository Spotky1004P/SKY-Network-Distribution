var entity = su.getEntity();
var dataMap = entity.getResourceState().getDataMap();

var notch = su.getNotch();
var speed = Math.abs(entity.getSpeed()*72);

var mvol = 0;
var mpit = 0;
var mvol = 0;
var mpit = 0;

function linener(x, a, b, c, d){
	return(b-d)/(a-c)*(x-a)+b;
}

var pck_flag = [];