function doorBeep(entity, dataMap, soundType, timer){
	if(entity.getTrainStateData(10) != 1){
		//Type별 이름, 길이 설정
		var typeNameList = ["train.rtm_pck_doorBeep_type1"];

		if(entity.doorMoveL != 0 || entity.doorMoveR != 0){ //열렸으면
			if(pck_doorBeep != 1){
				pck_doorBeep = 1;
			}
		}
		else if(pck_doorBeep != 0){
			if(pck_doorBeep == 2){ //안열렸고 타이머 도는중이면
				if(Date.now() > timer + pck_doorBeep_starttime){
					var path = new ResourceLocation("sound_pck2", typeNameList[soundType]);
					RTMCore.proxy.playSound(entity, path, 1, 1);
					pck_doorBeep = 0;
				}
			}
			else if(pck_doorBeep == 1){ //열려있다가 닫힐때 변경
				if(entity.doorMoveL == 0 && entity.doorMoveR == 0){
					pck_doorBeep = 2;
					pck_doorBeep_starttime = Date.now();
				}
			}
		}
	}
}
//pck_doorBeep 0: 초기화상태  1: 문 열림  2: 문 닫힘

var pck_doorBeep;
var pck_doorBeep_starttime;